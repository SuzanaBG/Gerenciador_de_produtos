import produtos from "./produtos.js";

console.log("Produtos:");
console.log(produtos());

console.log("\nNome dos produtos:");
produtos().map(({nome}) => console.log(nome));

console.log("\nProduto de código 1:");
produtos()
    .filter(({código}) => código == 1)
    .map(({nome}) => console.log(nome));
produtos()
    .filter(({código}) => código == 1)
    .map(({preço}) => console.log("R$ " + preço));

console.log("\nProduto de código 2:");
produtos()
    .filter(({código}) => código == 2)
    .map(({nome}) => console.log(nome));
produtos()
    .filter(({código}) => código == 2)
    .map(({preço}) => console.log("R$ " + preço));

console.log("\nProduto de código 3:");
produtos()
    .filter(({código}) => código == 3)
    .map(({nome}) => console.log(nome));
produtos()
    .filter(({código}) => código == 3)
    .map(({preço}) => console.log("R$ " + preço));
        
console.log("\nProduto de código 4:");
produtos()
    .filter(({código}) => código == 4)
    .map(({nome}) => console.log(nome));
produtos()
    .filter(({código}) => código == 4)
    .map(({preço}) => console.log("R$ " + preço));
    
console.log("\nProduto de código 5:");
produtos()
    .filter(({código}) => código == 5)
    .map(({nome}) => console.log(nome));
produtos()
    .filter(({código}) => código == 5)
    .map(({preço}) => console.log("R$ " + preço));

const array = produtos().map(({preço}) => {return preço});
var total = array.reduce(function(total, numero){
    return total + numero;
    }, 0);
console.log("\nMédia dos preços: R$ " + total/5);
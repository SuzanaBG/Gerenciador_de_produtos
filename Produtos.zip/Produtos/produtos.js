const produtos = [
    {"código": 1, "nome": "Papel", "preço": 5},
    {"código": 2, "nome": "Caneta", "preço": 1.5},
    {"código": 3, "nome": "Lápis", "preço": 1},
    {"código": 4, "nome": "Caderno", "preço": 20},
    {"código": 5, "nome": "Pasta", "preço": 35}
]

export default function(){
    return produtos;
}